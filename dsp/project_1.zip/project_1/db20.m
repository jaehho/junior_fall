function y=db20(x)

y=20*log10(abs(x));
return;
